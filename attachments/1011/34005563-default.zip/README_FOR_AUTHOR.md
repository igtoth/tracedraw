# Pull Request / Issue Proposal for TraceDraw

**Title**: `feat(i18n, ai): Complete zh-CN translation for AI features, 64k token limit & smart endpoint URL handling`

---

### English Description (for GitHub PR / Issue)

#### 1. Summary of Changes
This contribution brings three major improvements to TraceDraw's AI features and localization:

1. **Complete Chinese (zh-CN) Translation for AI Features** (`apps/tracedraw/lang/zh-CN.toml`):
   - Fully translated all previously untranslated English strings in `zh-CN.toml`, including:
     - The entire **AI Generate** docker panel (`aigen.*`): Create image, Remix image, Create vectors, prompts, aspect ratios, image styles, palettes, etc.
     - The **Options: AI** dialog (`aiui.*`, `options.ai_*`): Settings, services, connection test status, descriptions, and privacy notes.
     - All **AI Presets** (`aipreset.*`): Custom, Anthropic, OpenAI, Gemini, Ollama, LM Studio, llama.cpp, vLLM, OpenCode.
     - **AI Art Styles** and bitmap effects (`aiimg.*`).
     - **Painterly Brush** tools and dry/wet media (`painterly.*`).
     - Help topics and screen hints (`hintai.*`, `hinttopic.*`).

2. **Increase `MAX_TOKENS` from 8,000 to 64,000** (`apps/tracedraw/src/ai.rs`):
   - **Problem**: When users request detailed vector drawings (e.g. landscapes with multiple objects, figures, and decorative styles), modern reasoning models (Gemini 2.5/3.0, Claude 3.5 Sonnet, DeepSeek) output extensive JavaScript drawing scripts. With the hardcoded `8000` limit, requests frequently get cut off halfway (`stop_reason: "max_tokens"`), causing TraceDraw to reject the response with `"The reply was cut short; ask for less at a time."`.
   - **Fix**: Increased `MAX_TOKENS` to `64000`, matching modern model output ceilings and allowing complex vector drawings to complete reliably.

3. **Smart Endpoint URL Normalization** (`apps/tracedraw/src/ai.rs`):
   - **Problem**: Users running local proxies or custom servers often enter their base URL (e.g. `http://localhost:8787` or `http://localhost:8787/v1`). TraceDraw was sending `POST http://localhost:8787` directly without appending `/messages` or `/chat/completions`, which hits the proxy's web root (returning HTML) and fails with `"The reply of the service could not be read."`.
   - **Fix**: In `AiPrefs::endpoint()`, automatically append `/v1/messages` (for Anthropic) or `/v1/chat/completions` (for OpenAI) if only a host or base URL without the path is specified.

#### 2. Modified Files in this Directory
- `zh-CN.toml`: Drop-in replacement for `apps/tracedraw/lang/zh-CN.toml`.
- `ai.rs`: Updated source file for `apps/tracedraw/src/ai.rs`.
- `ai.rs.patch`: Standard git unified diff patch. You can apply it via:
  ```bash
  git apply ai.rs.patch
  ```

---

### 中文说明（提交给作者时的中文对照）

#### 1. 修改概述
1. **补全全部 AI 功能的简体中文翻译**：
   - 官方原版 `zh-CN.toml` 中，AI 模块的所有英文文本（约 215 条）已全部翻译为规范通顺的中文，包括“AI 生成”面板、提示词指导、风格/调色板预设、“选项: AI”设置窗口、帮助文档与菜单。
2. **解锁输出 Token 上限至 64,000**：
   - 解决用户在生成复杂矢量图（如多主体场景、细致风景）时，因原版写死的 8,000 Token 上限而导致回复被腰斩、报错“回复被截断，请一次少要求一些”的问题。
3. **优化自建 API 端点容错**：
   - 当用户在自定义服务地址中仅填写根地址（如 `http://localhost:8787`）时，自动补全 `/v1/messages` 或 `/v1/chat/completions`，避免打到代理网页根目录返回 HTML 导致解析失败。
